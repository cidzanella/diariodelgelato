export interface Gelato {
    id: number,
    name: string,
    description: string
}
