
export interface Conodelgiorno {
    idTeamMember: number;
    idGelatoA: number;
    idGelatoB: number;
    weight: number;
    timestamp: Date; 
}
