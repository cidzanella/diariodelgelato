export interface Credential
{
    userId: number;
    userName: string;
    isAdmin: boolean;
    token: string;
}

